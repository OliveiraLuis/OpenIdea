
  <main class="mdl-layout__content">
    <div class="page-content">
    <!-- Your content goes here -->
      <section id="secao1" class="slide">
            <h1>Compartilhe suas ideais com o mundo</h1>
            <p>O Open Idea foi pensado para todos os inovadores de plantão que desejam inovar o mundo em que vivem</p>
            <p>É feito para quem tem ideias inovadoras</p>
            <p>E para quem deseja tirar essas ideias do papel</p>
        </section>
        
        <section id="secao2" class="slide">
            <p>Mostre toda sua criatividade ao mundo</p>
            <p>Não tenha medo de não saber executar sua ideia, deixe-a para pessoas capacitadas em fazê-la</p>
        </section>
        
        <section id="secao3" class="slide">
            <p>Encontre um projeto com o qual se identifique</p>
            <p>Desenvolva projetos pensados pelos integrantes da comunidade</p>
        </section>
    </div>
