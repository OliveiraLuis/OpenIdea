<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	public function index()
	{
		$data['title'] = "Open Idea | Home";
		$this->load->view('util/cabecalho', $data);
		$this->load->view('main');
		$this->load->view('util/rodape');
	}
	
	public function entrar(){
		$data['title'] = "Open Idea | Entrar";
		$this->load->view('util/cabecalho', $data);
		$this->load->view('entrar');
		$this->load->view('util/rodape');

	}

	public function inscrever(){
		$data['title'] = "Open Idea | Criar conta";
		$this->load->view('util/cabecalho', $data);
		$this->load->view('inscrever');
		$this->load->view('util/rodape');
	}

	public function salvar(){
		$this->load->model('Crud_model');
		$this->Crud_model->table = "usuario";
		$data = $this->input->post();
		echo $this->Crud_model->Inserir($data);
	}
}
